from __future__ import annotations

import atexit
import os
import socket
import threading
import sys
import time
import webbrowser
from pathlib import Path

import uvicorn

HOST = "127.0.0.1"
PORT = 8765
APP_DIR = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
def _data_dir() -> Path:
    configured = os.environ.get("DIMITRY_HUB_DATA")
    if configured:
        return Path(configured).expanduser()
    if getattr(sys, "frozen", False) and os.name == "nt" and os.environ.get("LOCALAPPDATA"):
        return Path(os.environ["LOCALAPPDATA"]) / "Dimitry Hub" / "Data"
    return APP_DIR / "data"


PID_FILE = _data_dir() / "dimitry_hub.pid"
URL = f"http://{HOST}:{PORT}"


def open_browser(delay: float = 1.2) -> None:
    time.sleep(delay)
    webbrowser.open(URL)


def server_is_running() -> bool:
    try:
        with socket.create_connection((HOST, PORT), timeout=0.35):
            return True
    except OSError:
        return False


def remove_pid_file() -> None:
    try:
        if PID_FILE.exists() and PID_FILE.read_text(encoding="utf-8").strip() == str(os.getpid()):
            PID_FILE.unlink()
    except OSError:
        pass


if __name__ == "__main__":
    # Evita abrir dos servidores si el usuario pulsa el acceso directo varias veces.
    if server_is_running():
        webbrowser.open(URL)
        raise SystemExit(0)

    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(str(os.getpid()), encoding="utf-8")
    atexit.register(remove_pid_file)

    threading.Thread(target=open_browser, daemon=True).start()

    # Sin consola visible, desactivamos el registro de Uvicorn que normalmente
    # intenta escribir en stdout/stderr.
    uvicorn.run(
        "app.main:app",
        host=HOST,
        port=PORT,
        reload=False,
        access_log=False,
        log_config=None,
    )
