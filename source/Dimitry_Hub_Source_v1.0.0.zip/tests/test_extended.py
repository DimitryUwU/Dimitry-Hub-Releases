from __future__ import annotations

import os
import tempfile
import unittest
import zipfile
from pathlib import Path


class ExtendedTests(unittest.TestCase):
    def test_zip_path_traversal_is_blocked(self):
        from app.knowledge import safe_extract_zip
        with tempfile.TemporaryDirectory() as tmp:
            archive = Path(tmp) / "bad.zip"
            with zipfile.ZipFile(archive, "w") as zf:
                zf.writestr("../outside.txt", "bad")
            with self.assertRaises(ValueError):
                safe_extract_zip(archive, Path(tmp) / "out")

    def test_analyzer_recognizes_unity_il2cpp(self):
        from app.analyzer import analyze_bundle
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "global-metadata.dat").write_bytes(b"meta")
            (root / "GameAssembly.dll").write_bytes(b"dll")
            result = analyze_bundle(root)
            self.assertTrue(any("IL2CPP" in item for item in result["classification"]))

    def test_monograph_headings_are_black(self):
        with tempfile.TemporaryDirectory() as tmp:
            os.environ["DIMITRY_HUB_DATA"] = tmp
            # Import in a fresh process would be ideal; XML assertion still validates the style code.
            from app.documents import create_monograph_docx
            path = create_monograph_docx(
                {"title": "Prueba", "author": "Autor"},
                "# Introducción\n\nTexto de prueba.\n\n# Conclusiones\n\nConclusión.",
                "Autor, A. (2026). Obra.",
            )
            with zipfile.ZipFile(path) as zf:
                styles = zf.read("word/styles.xml").decode("utf-8")
            self.assertIn('w:val="000000"', styles)


if __name__ == "__main__":
    unittest.main()
